import { useState } from "react";
import { toast } from "react-toastify";

export default function PromptIdeaGenerator({ onGenerate }) {
  const [idea, setIdea] = useState("");
  const [loading, setLoading] = useState(false);

  const handleGenerate = async () => {
    if (!idea.trim()) return;
    setLoading(true);
    try {
      const res = await fetch("http://localhost:8000/api/prompts/generate-from-idea/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          goal: idea,
          audience: "AI assistant users",
          tone: "professional",
          key_points: ""
        }),
      });

      const data = await res.json();
      if (res.ok && data.slug) {
        onGenerate?.(data); // Pass the full prompt object directly
        toast.success("✅ Prompt generated!");
      } else {
        toast.error("❌ Failed to generate prompt.");
      }
    } catch (err) {
      console.error("Prompt generation failed:", err);
      toast.error("❌ Server error.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mb-3">
      <label className="form-label">🪄 Generate Prompt from Idea</label>
      <div className="input-group">
        <input
          type="text"
          className="form-control"
          placeholder="e.g. Build a startup agent that mentors junior developers"
          value={idea}
          onChange={(e) => setIdea(e.target.value)}
        />
        <button
          className="btn btn-outline-primary"
          type="button"
          disabled={loading}
          onClick={handleGenerate}
        >
          {loading ? "Generating..." : "Generate"}
        </button>
      </div>
    </div>
  );
}