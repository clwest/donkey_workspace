import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import "./styles/PromptDetailView.css";

export default function PromptDetailView() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const [prompt, setPrompt] = useState(null);
  const [loading, setLoading] = useState(true);
  const [mutationMode, setMutationMode] = useState("clarify");

  useEffect(() => {
    async function fetchPrompt() {
      try {
        const res = await fetch(`http://localhost:8000/api/prompts/${slug}/`);
        if (!res.ok) {
          throw new Error("Failed to fetch prompt");
        }
        const data = await res.json();
        setPrompt(data);
      } catch (err) {
        console.error("Error loading prompt:", err);
      } finally {
        setLoading(false);
      }
    }

    fetchPrompt();
  }, [slug]);

  async function handleDelete() {
    const confirmDelete = window.confirm("Are you sure you want to delete this prompt?");
    if (!confirmDelete) return;

    try {
      const res = await fetch(`http://localhost:8000/api/prompts/${slug}/`, {
        method: "DELETE",
      });

      if (!res.ok) throw new Error("Delete failed");

      toast.success("✅ Prompt deleted successfully!");
      navigate("/prompts");
    } catch (err) {
      console.error("Failed to delete prompt", err);
      toast.error("❌ Something went wrong while deleting.");
    }
  }

  if (loading) {
    return (
      <div className="container my-5 text-center">
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading prompt details...</span>
        </div>
        <p className="mt-3">Loading prompt details...</p>
      </div>
    );
  }

  if (!prompt) {
    return (
      <div className="container my-5 text-center">
        <h3>❌ Prompt not found.</h3>
        <button
          className="btn btn-outline-secondary mt-3"
          onClick={() => navigate("/prompts")}
        >
          🔙 Back to Prompts
        </button>
      </div>
    );
  }

  return (
    <div className="container my-5">
      <h1 className="mb-4">{prompt.title}</h1>

      <p className="text-muted mb-4">
        Type: {prompt.type} | Source: {prompt.source} | Token Count: {prompt.token_count}
      </p>

      <div className="bg-light p-3 rounded mb-4">
        <pre className="mb-0">{prompt.content}</pre>
      </div>

      <div className="d-flex gap-3 align-items-center">
        <select
          className="form-select"
          style={{ maxWidth: "200px" }}
          value={mutationMode}
          onChange={(e) => setMutationMode(e.target.value)}
        >
          <option value="clarify">Clarify</option>
          <option value="expand">Expand</option>
          <option value="shorten">Shorten</option>
          <option value="formalize">Formalize</option>
          <option value="casualize">Casualize</option>
          <option value="convertToBulletPoints">Bullet Points</option>
        </select>

        <button
          className="btn btn-primary"
          onClick={() =>
            navigate(`/prompts/${slug}/remix`, {
              state: {
                mode: mutationMode,
                remixedContent: prompt.content,
              },
            })
          }
        >
          ✨ Apply Mutation
        </button>

        <button className="btn btn-danger" onClick={handleDelete}>
          🗑️ Delete Prompt
        </button>
      </div>
    </div>
  );
}